

#ifndef UNLZ4_H_INCLUDED

void unlz4(const void *aSource, void *aDestination);
void unlz4_len(const void *aSource, void *aDestination, uint32_t aLength);

#endif  // UNLZ4_H_INCLUDED
for x in *.packed
    do
	O=$(echo $x | sed 's,\.packed$,.o,')
	arm-none-eabi-ld -r -o $O -z noexecstack --format=binary $x
	arm-none-eabi-objcopy --rename-section .data=.rodata,alloc,load,readonly,data,contents $O
    done